    #ifndef MACHINIST_H
    #define MACHINIST_H
    #include <ncurses.h>

    //inventory with descriptions
    struct Inventory{
      char item[50];
      char description[200];
    };

    //Description of locations with id and destiny-id
    //description for each of the four daytimes
    struct Location{
        char ort[20];
        int id;
        int destinations[10];
        char *daytime_texts[4];
    };

    void add_item(const Inventory *ob);
    void remove_item(WINDOW *items, int a);
    void show_inventory(WINDOW*items);
    void bubbleSort();
    void add_location();
    void read_locations();
    void useItem(WINDOW *items, WINDOW *text, WINDOW*command, WINDOW*time);
    int makeMap(const char*);
    void readScene();
    void readDaytime();
    void printstuff(WINDOW *text, WINDOW *command, const char *tlmp);
    int getNumber(const char *a);
    extern int mx, my;
    extern Location locations[7];
    extern char *scene_texts[10];
    extern int gamestate;
    extern bool bottle;
    extern bool nutbar;
    extern bool machinistsHeart;
    extern bool hermitsGratitude;
    extern bool hermit;
    extern bool hydra;

#endif