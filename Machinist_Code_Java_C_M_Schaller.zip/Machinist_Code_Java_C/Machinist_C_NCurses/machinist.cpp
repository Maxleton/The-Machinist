    #include "machinist.h"
    #include <stdio.h>
    #include <string.h>
    #include <ncurses.h>
    #include <stdlib.h>

    static Inventory *ptr=NULL;
    static int count=0;
    static int platzhalter=0;
    static int nur_fuer_server=2;
    static bool am_ende=true;
    extern int mx;
    extern int my;
    extern WINDOW *items;
    extern WINDOW *text;
    extern WINDOW *command;
    extern WINDOW *daytime;
    extern int current_id;
    extern double iWidth;
    Location locations[7];
    char *scene_texts[10];
    ssize_t mygetdelim(char **lineptr, size_t *n, int delim, FILE *stream);

    //Swaps two pointers after certain criteria
    void swap(Inventory *ob1, Inventory *ob2) 
    { 
    Inventory temp = *ob1; 
    *ob1 = *ob2; 
    *ob2 = temp; 
    } 

    //Checking for alphabetical order, if not swap()
    void bubbleSort() 
    { 
    for (int i = 0; i < count-1; i++) {      
           // Last i elements are already in place    
     for (int j = 0; j < count-i-1; j++)  {
       if (strcasecmp(ptr[j].item, ptr[j+1].item)>0) {
        swap(&ptr[j], &ptr[j+1]);
      }
    }
    }
    }

    //Building of object register
    //if struct is greater, creating a bigger one
    //then bubbleSort()
    void add_item(const Inventory *ob)
    {
    if(count==0){
      ptr=new Inventory[count+1];
      ptr[count]=*ob;
      count++;
    }else{
      Inventory *tmp=new Inventory[count+1];
      for(int i=0; i<(count);i++){
        tmp[i]=ptr[i];
      }
      tmp[count]=*ob;
      delete ptr;
      ptr=tmp;
      count++;
    }
    bubbleSort();
    }

    //Creating of smaller inventory 
    //deleting item of certain number
    //then sorting and printing in window "items"
    void remove_item(WINDOW *items, int a)
    {
    Inventory *tmp=new Inventory[count-1];
    for(int i=0; i<(count);i++){
      if(i<a) tmp[i]=ptr[i];
      if(i==a) continue;
      if(i>a) tmp[i-1]=ptr[i]; 
    }
    delete ptr;
    ptr=tmp;
    count--;
    bubbleSort();
    show_inventory(items);
    }

    //printing of inventory in window "items"
    void show_inventory(WINDOW* items)
    {
    wclear(items);
    box(items, 0, 0);
    mvwprintw(items,1,1, "INVENTORY");
    for (int i=0; i<count;i++){
      mvwprintw(items,i+2,1, "-%s", ptr[i].item);
    }
    wrefresh(items);
    }

    //Reading locations from textfile
    //made in discussion with Florian Güthlein
    void read_locations(){
    FILE *file=fopen("locations.txt","r");
    if (file == NULL) {
      perror("fopen");
      exit(1);
    }
    char src[20], dst[20];
    char line[40];
    for (int i=0; i<sizeof(locations)/sizeof(locations[0]);i++){
      locations[i].id=-1;
      for (int j=0;j<4;j++)
      locations[i].daytime_texts[j]=0;
    }
    while (fgets(line,40,file) != NULL) {
      char *limit = strchr(line, '>');
      for(int i=0; i<limit-line;i++){
        src[i]=line[i];
      }
      src[limit-line]='\0';
      int lilength= strlen(line);
      for(int i=limit-line+1,j=0; i<lilength;i++,j++){
        dst[j]=line[i];
        if (line[i]=='\n' || line[i] == '\r')dst[j]='\0';
      }
      int src_id = makeMap(src);
      int dst_id = makeMap(dst);
      for(int i =0; i<sizeof(locations[src_id].destinations)/sizeof(locations[src_id].destinations[0]);i++){
        if(locations[src_id].destinations[i]==-1){
          locations[src_id].destinations[i]=dst_id;
          break;
        }
      }
      //fprintf(stderr,"src %s  %d dst %s  %d\n", src, src_id,dst,dst_id);
    }
    fclose(file);

    /*for (int i = 0; i !=7; i++) {
      printf("%s :", locations[i].ort);
      for (int j = 0; j != 10;++j){
        if (locations[i].destinations[j] == -1)
          break;
        else
          printf("%s ", locations[locations[i].destinations[j]].ort);
        putchar('\n');
      }
      }
      */
    }

    //putting locations into right relationship
    //made in discussion with Florian Güthlein
    int makeMap(const char* tmp){
      for (int i=0; i<sizeof(locations)/sizeof(locations[0]);i++){
        if(locations[i].id==-1){
          strcpy(locations[i].ort, tmp);
          locations[i].id=i;
          for(int j=0;j<sizeof(locations[i].destinations)/sizeof(locations[i].destinations[0]);j++){
            locations[i].destinations[j]=-1;
          }
          return i;
        }
        int cmp = strcmp(locations[i].ort,tmp);
        if(cmp==0){
          return i;
        }  
      }
      return -1;
    }

    //creating of menue
    //highlighting of current item
    //printing of description in "text"
    void useItem(WINDOW *items, WINDOW *text, WINDOW *command, WINDOW*time){
      keypad(items, true);
      int highlight=0;
      mvwchgat(items, 2+highlight, 1, iWidth-2, A_STANDOUT, 1, NULL);
      while(1){
        int choice;
        choice=wgetch(items);
        if(choice==KEY_UP || choice == KEY_DOWN){
          mvwchgat(items, 2+highlight, 1, iWidth-2, A_NORMAL, 1, NULL);
        switch(choice)
        {
          case KEY_UP:
          highlight--;
          if(highlight==-1) highlight=0;
          break;
          case KEY_DOWN:
          highlight++;
          if(highlight==count) highlight =count-1;
          break;
          default:
          ;
        }
        mvwchgat(items, 2+highlight, 1, iWidth-2, A_STANDOUT, 1, NULL);
      }
        if(choice==10)break; //enter
        //if(choice==27)break; //escape
      }
      printstuff(text, command, ptr[highlight].description);

      //interaction with bottle
      if(strcmp(ptr[highlight].item, "filled bottle")==0) 
        {
          printstuff(text,command,"It has been some time since they last hydrated. The Machinist lowers their scarf to take in what is left of the precious liquid. Before they can stop themselves the vessel makes a hollow sound as they try to drink more. There is nothing left. Perhaps it can be refilled somewhere.");
          remove_item (items, highlight);
          Inventory em_bo={"empty bottle", "An empty bottle made from aluminum."};
          add_item(&em_bo);
        }
      if(locations[current_id].id ==4 && daytime==0 && strcmp(ptr[highlight].item, "empty bottle")==0){
        printstuff(text, command, "The water seems to have cooled down a bit. Maybe it could be put to use now. Carefully the Machinist lowers one ungloved finger to the still hot water. Against their expectation they don't burn themselves, even though the nearly boiling water is not the least pleasant on their skin. The manage to refill their empty vessel.");
        Inventory fi_bo={"filled bottle", "The tube contains enough liquid to keep someone alive in the heat of day. Though one should not leave the shelter of the Great Cities in the first place."};
        add_item(&fi_bo);
      }else if(locations[current_id].id ==4 && daytime!=0 && strcmp(ptr[highlight].item, "empty bottle")==0){
        printstuff(text,command,  "The is no use in waiting for better times when there is an empty bottle and one cannot say how long "
                          "it will be until they have the next chance to refill. Slowly the Machinist opens their bottle to fill it with "
                         "some of the lake's water, only to flinch away in pain as the boiling hot water burns their skin. "
                          "Perhaps now is not the best time for that.");

        //Relevant items in event redBeasts()
      }else if(locations[current_id].id==1 && daytime==0 && strcmp(ptr[highlight].item, "nutrition bar")==0){
        printstuff(text, command, "Probably the only thing these hounds want is not to starve. They would be left without food, but be torn to shreds by some grotesque animals "
               "as hardly better. Slowly reaching into their bag the machinist picks the nutrition bars they... found... at the Chunkyards and throws them toward "
               "the beast as they spin around and run. Their boots are sounding unbearably loud with every step. Against all odds their plan must have worked because of "
               "the lack of animal teeth in the Machinist's flesh. Even so they don't stop running until their muscles and lunges protest in pain. Turning around they only "
               "see the empty red of the Red Wastelands.\n");
          remove_item (items, highlight);
          nutbar=false;
      }else if(locations[current_id].id==1 && daytime==0 && strcmp(ptr[highlight].item, "crowbar")==0){
        printstuff(text, command, "Sometimes there are no other options left than violence. Even for a simple machinist. Sometimes the only option is to use a crowbar to defend one's life. "
               "And 'sometimes' means now. As the first of the beast lunges toward the Machinist they bring down their improvised weapon with a heavy blow, hearing the"
               "whincing of a hurt animal, breaking of bones and the ringing of metal against metal. That wasn't so difficult after all. Bringing themselves into some kind of ready position the "
               "beasts start to circle them snarling. Once more the Machinist lashes out with the crowbar, connecting to the shoulder of the know more cautious hound. "
               "They remain like that for a minute, neither of them really sure how to react. Then with a painfull bark the beasts retreat into the distance.\n");
      }else if(locations[current_id].id==1 && daytime==0 && (strcmp(ptr[highlight].item, "crowbar") && strcmp(ptr[highlight].item, "nutrition bar"))!=0){
      printstuff(text, command, "Before the Machinist can decide one of the beast brings them down with its heavy body. Caught in their bite the Machinist gets trown "
               "further over the harsh ground. Their head hits something for their vision goes blurry and there now is a crack in their goggles. "
               "Sharp claws tear through their clothing, piercing into their skin. A snarl, then another. Thoughts build in the "
               "Machinist's head of what they could do next. In vain. Powerful jaws seize their neck. There is pain. Then there is nothing anymore.\n");
          gamestate = 3;
        }
      show_inventory(items);
      wrefresh(text);
    }

    //reading of data from file via tags
    //made in discussion with Florian Güthlein
    void readData(FILE*file, char **tag, char **txt)
    {
      char tmp;
      char prv=' ';
      int count=0;
      char *text=NULL;
      bool tagread=false;
      *tag = NULL;
        while ((tmp=fgetc(file)) != EOF) {
          if(tmp=='/'&&prv !='/'){
            prv='/';
          }else if(tmp=='/'&&prv =='/'){
            prv=' ';
            char c;
           while((c=fgetc(file)) != '\n' && c!= EOF)
           {

           }
           if (tagread) {
            text[count-1]='\0';
            count--;
          }
            continue;
          }
          if(tmp=='<'){
            tagread=true;
            char *lineptr=NULL;
            size_t n=0;
            size_t sz = mygetdelim(&lineptr, &n, '>', file);
           lineptr[sz-1]='\0';
           char c;
           while((c=fgetc(file)) != '\n' && c!= EOF)
           {

           }
           if(lineptr[0]!='\\'){
               *tag=lineptr;
            } else {
               free(lineptr);
               break;
           }
          }
          else if (tagread==true) {
            if (tmp == '\r')
              continue;
            text = (char*) realloc(text, count+1);
            text[count]=tmp;
            count++;
          }
        }
        text = (char*) realloc(text, count+1);
        text[count]='\0';
        count++;
        *txt=text;
    }

    //reading of daytime.txt 
    //made in discussion with Florian Güthlein  
    void readDaytime()
    {
    FILE *file=fopen("daytime.txt","r");
    if (file == NULL) {
      perror("fopen");
      exit(1);
    }
    char*tag;
    char*txt;
    while (!feof(file)) {
      readData(file, &tag,&txt);
      if (tag == NULL)
        break;
      int id = atoi(tag+1);
      int time;
      switch(tag[0]){
        case 'n':
          time=0;
          break;
        case 'm':
          time=1;
          break;
        case 'z':
          time=2;
          break;
        case 's':
          time=3;
          break; 
      }
      locations[id].daytime_texts[time] = txt;
      fprintf(stderr,"%d %d %s   %s", id, time, tag, txt);
    }
    fclose(file);  
    }

    //reading of scenes.txt 
    //made in discussion with Florian Güthlein
    void readScene()
    {
    FILE *file=fopen("scenes.txt","r");
    if (file == NULL) {
      perror("fopen");
      exit(1);
    }
    char*tag;
    char*txt;
    while (!feof(file)) {
      readData(file, &tag,&txt);
       if (tag == NULL)
        break;
       int id = atoi(tag);
      scene_texts[id] = txt;
    }
    fprintf(stderr, "%s  %s\n", tag, txt);
    fclose(file);
    }

    int getNumber(const char *a){
    for (int i=0; i<count;i++){
      int temp= strcmp(a, ptr[i].item);
      if(temp==0) return i;
    }
    return -1;
    }

  //Implementation of getdelim() in current C version
  ssize_t mygetdelim(char **lineptr, size_t *n, int delim, FILE *stream){
    char *temp=NULL;
    while(true){
      temp=(char*)realloc(temp, *n+1);
      int a=fgetc(stream);
      if(a==EOF) break;
      temp[*n]=a;
      (*n)++;
      if(temp[*n-1]== (char) delim) break;
    }
    temp=(char*)realloc(temp, *n+1);
    *lineptr=temp;
    temp[*n]='\0';
    return *n;
  }