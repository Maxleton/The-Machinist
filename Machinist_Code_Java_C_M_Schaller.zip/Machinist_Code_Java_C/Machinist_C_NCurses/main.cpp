  #include <ncurses.h>
  #include <unistd.h>
  #include <string.h>
  #include <ctype.h>
  #include <stdio.h>
  #include "machinist.h"

  //Parameter
  int gamestate=0;
  int daytime=2;

  int current_id=1;
  double iWidth;
  void startscreen();
  void journey(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time);
  void events(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time);
  void ending(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time);
  void setup();
  void fill_inventory();
  void checkForDaytime(WINDOW*time, WINDOW *text, WINDOW*command);
  void checkForAction(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time);
  void build_windows(WINDOW **in_time, WINDOW ** in_command, WINDOW **in_items, WINDOW **in_text);
  int getText(WINDOW *command, int a);
  void printstuff(WINDOW *text, WINDOW *command, WINDOW *time, const char *tlmp);
  void theHermit(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time);
  void redBeasts(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time);
  void clockworkHydra(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time);
  int mx, my;
  int varx, vary;
  bool machinistsHeart=false;
  bool hermitsGratitude=false;
  bool hermit=false;
  bool hydra=false;
  bool nutbar=false, crowbar =false;
  bool bottle=true;

  int main(int argc, char *argv[])
  {
  //Building of windows, putting off of mouse pointer
  initscr();
  curs_set(FALSE);
  noecho();

  getmaxyx(stdscr, my,mx);

  clear();

  //building of subwindows
  WINDOW*time;
  WINDOW*command;
  WINDOW*items;
  WINDOW*text;

  startscreen();
  build_windows(&time, &command, &items,&text);

  printstuff(text, command, scene_texts[0]);

  checkForDaytime(time, text, command);

  while(1){
   if (gamestate==1){
     journey(command, text, items, time);
   }
   else if (gamestate==2){
     events(command, text, items, time);
   }else if (gamestate==3){
     ending(command, text, items, time);
     break;
   }else{
     break;
   }
  }

  refresh();
  endwin();

  return(0);
  }

  //Introscreen
  //Start of Gameloop
  void startscreen(){
  setup();
  //keypad(stdscr, TRUE);
  mvprintw(my-1,1,"press ctrl+c to quit");
  refresh();

  while(gamestate==0){
  attrset(A_BOLD);
    const char text[]="START JOURNEY"; //Introscreen
    int len=strlen(text);
    mvprintw(my/2,mx/2-len/2-1,text);
    attrset(A_NORMAL);

    attrset(A_BLINK);
    const char start[]="Press ENTER to continue";
    int len2=strlen(start);
    mvprintw(my/2+1,mx/2-len2/2-1,start);
    attrset(A_NORMAL);
    refresh();

    int ch = getch();
    if(ch!=EOF)
    {
      if(ch == 10){ //Enter
        gamestate=1;
        break;
      }else if(tolower(ch)=='q')break;
    }
  }
  }

  //building of text, command, time and items in dependence to main window 
  //printing of time and inventory
  void build_windows(WINDOW **in_time, WINDOW ** in_command, WINDOW **in_items, WINDOW **in_text){
  static double iHeight=my*0.62;
  iWidth=mx*0.23;
  static double iStarty=my-(my*0.64);
  static double iStartx=mx-(mx*0.23);
  *in_items = newwin(iHeight,iWidth, iStarty, iStartx);
  WINDOW *items = *in_items;
  box(items,0,0);
  show_inventory(items);
  wrefresh(items);

  static double tHeight=my*0.33;
  static double tWidth=mx*0.23;
  static double tStarty=1;
  static double tStartx=mx-(mx*0.23);
  *in_time = newwin(tHeight,tWidth, tStarty, tStartx);
  WINDOW *time=*in_time;
  wclear(time);
  box(time, 0, 0);
  wattron(time,A_BOLD);
  //checkForDaytime(time,text);
  wrefresh(time);

  static double txtHeight=my*0.66;
  static double txtWidth=mx*0.73;
  static double txtStarty=1;
  static double txtStartx=1;
  *in_text = newwin(txtHeight,txtWidth, txtStarty, txtStartx);
  WINDOW *text=*in_text;
  wclear(text);
  box(text, 0, 0);
  wrefresh(text);
  delwin(*in_text);
  *in_text = newwin(txtHeight-2,txtWidth-4, txtStarty+1, txtStartx+2);
  text=*in_text;
  wclear(text);
  scrollok(text, TRUE);
  wrefresh(text);


  static double cHeight=my*0.3;
  static double cWidth=mx*0.73;
  static double cStarty=my*0.7;
  static double cStartx=1;
  *in_command = newwin(cHeight,cWidth, cStarty, cStartx);
  WINDOW *command=*in_command;
  wclear(command);
  box(command, 0, 0);
  wattron(command,A_BOLD);
  mvwprintw(command,1,1, "WHAT IS THE MACHINIST'S NEXT OBJECTIVE?");
  wattroff(command,A_BOLD);
  wrefresh(command);
  }

  //printing of texts via ptrs 
  //made in discussion with Florian Güthlein
  void printstuff(WINDOW *text, WINDOW *command, const char *tlmp)
  {
  wclear(command);
  box(command, 0, 0);
  wclear(text);
  //box(text,0,0);
  int szy, szx; 
  getmaxyx(text, szy, szx);
  int x, y;
  wmove(text, 0,0);
  for (;*tlmp!='\0';tlmp++){

    waddch(text, *tlmp);
    getyx(text, y, x);
    wrefresh(text);

    getyx(text, y, x);
    if (*(tlmp+1) == ' '){
      const char *strsp = strchr(tlmp+2, ' ');
      int n;
      if (strsp ==NULL){
        n=strlen(tlmp);
      }else{
        n= strsp- tlmp;
      }
      if (n-1>=(szx-x)){
        wmove(text,y+1,0);
        ++y;
        tlmp++;
        if (*tlmp == '\0')
          break;
      }
    }
    if(y==szy-1) {
      wrefresh(text);
      wclear(command);
      box(command, 0, 0);
      mvwprintw(command,1,1, "Press Key.");
      wrefresh(command);
      int c=wgetch(command);
      wclear(text);
      wmove(text, 0,0);
    }
  }
  wrefresh(text);
  wclear(command);
  box(command, 0, 0);
  mvwprintw(command,1,1, "Press Key.");
  wrefresh(command);
  int c=wgetch(command);
  wclear(text);
  }

  //Building of main window
  //Filling of inventory
  void setup(){
  keypad(stdscr,TRUE);
  clear();
  start_color();
  init_pair(1, COLOR_WHITE, COLOR_BLACK);
  init_pair(2, COLOR_RED, COLOR_BLACK);
  init_pair(3, COLOR_GREEN, COLOR_BLACK);
  init_pair(4, COLOR_BLUE, COLOR_BLACK);

  color_set(2,NULL);
  border(ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
   ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER, ACS_LRCORNER);
  color_set(1,NULL);
  fill_inventory();  //via inventory Array

  //reading of locations, time, scenes
  read_locations();
  readDaytime();
  readScene();


  mvprintw(my-1,1,"press ctrl+c to quit");
  refresh();
  }

  //checking of daytime
  //printing of daytime in "time"
  //checking for event criteria
  void checkForDaytime(WINDOW*time,WINDOW*text, WINDOW*command){
  hydra= false;
  wclear(time);
  box(time, 0, 0);
  if(daytime>3){
    daytime=0;
  } 
  if(daytime==0){
    mvwprintw(time,1,2, "  NIGHT");
    mvwprintw(time,3,2, "         c  ");
    mvwprintw(time,5,2,"  ____________" );
  }else if(daytime==1){
    mvwprintw(time,1,2, "  SUNRISE");   
    mvwprintw(time,4,2,"     o        ");
    mvwprintw(time,5,2,"  ____________" );
  }else if(daytime==2){
    mvwprintw(time,1,2, "  SUN'S ZENIT");
    mvwprintw(time,3,2, "       o    ");
    mvwprintw(time,5,2,"  ____________" );
  }else if(daytime==3){
    mvwprintw(time,1,2, "  SUNSET");     
    mvwprintw(time,5,2,"  ________o___" );
  }
  wrefresh(time);     
  printstuff(text, command, locations[current_id].daytime_texts[daytime]);
  if (current_id==6 && (daytime==0 || daytime==3) && hydra==false){
   gamestate=2;
  }else{ 
  hydra=false;
  }
  if(current_id==1 && daytime==3) gamestate=2;
  if(current_id==1 && daytime==0) gamestate=2;
  }

  //Filling of inventory
  void fill_inventory(){
  static Inventory inventory[5]={
    "worn goggles", "A pair of old iron goggles. The echo of countless machinists before glimmering in their lenses.",
    "machinist tools", "A machinist without their tools is just a really capable mind. With them on the other hand one can fix nearly everything.",
    "scarf", "A sand coloured scarf. Hard to say whether that's its original colour or just a result of countless hours of work and sweat.",
    "filled bottle", "The tube contains enough liquid to keep someone alive in the heat of day. Though one should not leave the shelter of the Great Cities in the first place.",
    "glowcube", "A small cube shaped object, rich with ornaments, that sheds a somewhat warm light in a small circle when activated.",
  };
  for (int i=0;i<sizeof(inventory)/sizeof(inventory[0]);i++){
    add_item(&inventory[i]);
  }
  }

  //Standard- Gameloop
  void journey(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time){
  while (gamestate==1){
    checkForAction(command,text,items,time);
  }
  }

  //Playeroptions: travel, wait, inspect, use object
  void checkForAction(WINDOW *command, WINDOW *text, WINDOW *items, WINDOW *time){
  checkForDaytime(time,text,command);
  wclear(command);
  box(command, 0, 0);
  //wclear(text);
  //box(text, 0, 0);
  wattrset(command, A_BOLD);
  mvwprintw(command,1,1, "WHAT IS THE MACHINIST'S NEXT OBJECTIVE?");
  wattrset(command, A_NORMAL);
  wattrset(command, A_REVERSE);
  mvwprintw(command, 2,1,"Travel(0)");
  mvwprintw(command, 3,1,"Wait(1)");
  mvwprintw(command, 4,1,"Inspect_Area(2)");
  mvwprintw(command, 5,1,"Inventory(3)");
  wattrset(command, A_NORMAL);

  char temp=getText(command,  4);
  char t2;
  int tempcount=0;
  int c;
  switch(temp){
    case 0:
    //wclear(text);
    //box(text, 0, 0);
    wclear(command);
    box(command, 0, 0);
    mvwprintw(command,1,1, "There are several places to look for what is lost:" );
    for (int i=0;i<sizeof(locations[current_id].destinations)/sizeof(locations[current_id].destinations[0]);i++, tempcount++){
      int id = locations[current_id].destinations[i];
      if(id==-1) break;
      mvwprintw(command,i+2,1, "%s (%d)", locations[id].ort, i);
    }
    wrefresh(command);
    t2=getText(command,tempcount);
    current_id=locations[current_id].destinations[t2];

    //mvwprintw(text,0,0, "%s", locations[current_id].ort);
    //wrefresh(text);
    daytime++;
    checkForDaytime(time,text,command);
    break;
    case 1:
    wclear(text);
   // box(text, 0, 0);
    mvwprintw(text, 0,0,"This is as good a place to rest as any. An object can be repaired but it takes a different set of skills to fix a failing body. Better to wait and make some miles later.");
    wrefresh(text);
    daytime++;   
    wclear(command);
    box(command, 0, 0);
    mvwprintw(command,1,1, "Continue journey? Press Key.");
    wrefresh(command);
    c=wgetch(command);
    checkForDaytime(time, text,command);
    wclear(text);
    box(command, 0, 0);
    wrefresh(command);
    break;

    //findable Items (only) in Chunkyards
    case 2:
    wclear(text);
    if((current_id==4) && (daytime==1 || daytime==2) && nutbar==false){
      mvwprintw(text,0,0, "Some of the workers seem to have forgotten to put away their food after break. It would be a shame to leave that unused for some beast to find.");
      wrefresh(text);
      wclear(command);
      box(command, 0, 0);
      mvwprintw(command,1,1, "Continue journey? Press Key.");
      wrefresh(command);
      c=wgetch(command);
      nutbar=true;
      Inventory nut_bar ={"nutrition bar", "A bar of pressed protein, fibre and just enough vitamins not to die."};
      add_item(&nut_bar);         
    }else if(current_id==4 && (daytime==3 || daytime==0) && crowbar==false){
      mvwprintw(text, 0,0, "Amidst the machinery and chunkpiles the Machinist recognizes something that could be useful. Some of the workers seem to be doing a poor job leaving their tools lying around. It is as they say: Someone's failure is another one's crowbar.");
      wrefresh(text);
      wclear(command);
      box(command, 0, 0);
      mvwprintw(command,1,1, "Continue journey? Press Key.");
      wrefresh(command);
      c=wgetch(command);
      crowbar=true;
      Inventory crowbar={"crowbar", "A massive tool of pure iron. Usually used for heavy working and breaking down structures this object could be useful in many ways, including stabilizing something or as a weapon."};
      add_item(&crowbar);   
    }else{
      mvwprintw(text, 0,0, "Nothing to find here.");
    }
    show_inventory(items);
    //wrefresh(items);
    wrefresh(text);   
    break;
    case 3:
    useItem(items, text, command, time);
  }
  }

  //Reading of chars via command
  int getText(WINDOW*command,int a){
  while(1){
    int ch=wgetch(command);
    int val = ch-'0';
    if(val>-1 && val<a) return val;
  }
  return 0;
  }

  //Events
  void events(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time){
  if(current_id==1 && daytime ==3) theHermit(command, text, items, time);
  if(current_id==1 && daytime ==0) redBeasts(command, text, items, time);
  if(current_id==6 && (daytime ==3 || daytime==0)) clockworkHydra(command, text, items, time);
  if (gamestate == 2)
    gamestate = 1;
  }

  //Endings
  void ending(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time){
  while(gamestate==3){
    if(current_id==0){
      printstuff(text, command, scene_texts[1]);
      break;
    }else if((current_id==6 && machinistsHeart==false) || current_id==1){
      printstuff(text, command, scene_texts[2]);
      break;
    }else if(current_id==6 &&machinistsHeart==true && hermitsGratitude==false){
      printstuff(text, command, scene_texts[3]);
      break;
    }else if (current_id==6 &&machinistsHeart==true && hermitsGratitude==true){
      printstuff(text, command, scene_texts[4]);
      break;
    }
  }
  }

  //Interaktion with Hermit
  //after conversation hermit = true, different endings
  //if nutrition bar and filled bottle in inventory hermitsGratitude=true, different ending
  void theHermit(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time){
  checkForDaytime(time,text,command);
  printstuff(text, command,  "Looking around the Machinist notices a hooded figure approaching in the distance. "
   "The shrug. Unusual to meet another soul out here. Most of all now that the sun is sinking. "
   "No one in there right mind would stay out here at night. The irony of that statement doesn't escape the Machinist.\n");
  wclear(command);
  box(command, 0, 0);
  mvwprintw(command,1,1, "What shall the Machinist do?");
  mvwprintw(command,2,1, "Leave(0)");
  mvwprintw(command,3,1, "Wait(1)");
  wrefresh(command);
  int temp = getText(command, 2);
  switch (temp) {
    case 0:
    daytime++;
    break;
    case 1:
    printstuff(text, command, "Waiting for the person to approach the Machinist chooses a lean rock formation to build their camp for the night. Pulling out their glowcube a shimmer "
     "of warm light engulfes them and the surrounding area. Hopefully the rocks are enough of a shelter to not attract any predators. "
     "As the stranger comes closer more gets visible of their crooked form. There is nothing worth mentioning about them. "
     "Their smile reveals a set of sand coloured teeth that glimmer like gold and their skin bears the mark of age and the rough climate of the outer regions, "
     "making it impossible to determine the gender of the person. Not that it would change anything.\n");
    if (hermit == true) {
      printstuff(text, command, "'It's good to see you, friend. How have you been since the last time? Care to share meal and supplies?' \n");
    } else {
      printstuff(text, command, "'That's an unfamiliar face for ya! Night's gonna get dark and me's not to thrilled to find out what's out there. "
       "Allright for me to stay here for some time?'\n");
    }
    wclear(command);
    box(command, 0, 0);
    mvwprintw(command,1,1,"How shall the Machinist react?");
    mvwprintw(command,2,1,"Accept(0)");
    mvwprintw(command,3,1,"Decline(1)");
    wrefresh(command);
    temp= getText(command,2);
    switch (temp) {
      case 1:
      printstuff(text, command, "The stranger looks at them in a combination of sadness and understanding. They slowly nod. "
       "'I see. Dangerous as it is out here I wouldn't trust some hermit either. Fare well then! And may our next meeting be a pleasant one!' "
       "As if they had been a mere dream the Hermit fades back into the shadows, leaving the Machinist on their own on the hard grounds of the Red Wastelands. \n");
      gamestate = 1;
      break;
      default:
      temp = 0;
      case 0:
      printstuff(text, command, "Indifferent the Machinist gestures to the stranger to sit opposite them who then follows. "
       "The stranger, perhaps one of the rare, but somehow famous hermits studies the glowcube for a while as if reminiscing. "
       "'So' they say, 'You're one of them machinists, aren't you?\n");
      wclear(command);
      box(command, 0, 0);
      mvwprintw(command,1,1, "Sarcastic(0)");
      mvwprintw(command,2,1, "Nod(1)");
      mvwprintw(command,3,1, "Stay Silent(2)");
      wrefresh(command);
      temp=getText(command,3);
      if (temp==2) {
        printstuff(text, command, "Reluctant the Machinists avoids the Hermit's looks. It's not their matter who they are. In fact they hadn't even expected company out here. \n");
      } else if (temp==0) {
        printstuff(text, command, "The Machinist growls. 'What gave it away?' "
         "Smirking the Hermit taps on their forehead. 'It's those goggles. Haven't seen those in a long time. Saying is, "
         "you people don't get buried with 'em. You pick them up from your dead and make them your own. Ain't that right?'\n");
        wclear(command);
        box(command, 0, 0);
        mvwprintw(command,1,1, "Honest(0)");
        mvwprintw(command,2,1, "Indifferent(1)");
        mvwprintw(command,3,1, "Stay Silent(2)");
        wrefresh(command);
        temp=getText(command,3);
        if (temp==2) {
          printstuff(text, command, "The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
        } else if (temp==1) {
          printstuff(text, command,  "The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
           "Shrugging the Machinist replies through their scarf 'It is a way of proofing someone's worth and managing ressources. "
           "No point in wasting a pair of perfectly fine goggles.' "
           "They wait for Hermit to answer. Instead they bring their hand to their chin in consideration. "
           "'I find no wrong with that.' they say. \n");
        } else if (temp==0) {
          printstuff(text, command, "The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
           "Shrugging the Machinist tries to put their thoughts to words 'It may not be easy to understand but there are certain ways to "
           "do things in the machinists' community. One grows up fixing things and being taught to fix. One follows the guiding of their teacher, "
           "and the day they die a student who has been taught until that day has proven worthy enough to wear their teacher's goggles and start taking "
           "their own students. One doesn't teach someone not worthy of becoming a machinist. And besides that... "
           "No point in wasting a pair of perfectly fine goggles.' "
           "They wait for Hermit to answer. Instead they bring their hand to their chin in consideration. "
           "'I find no wrong with that.' they say. \n");
        } else {
          printstuff(text, command, "The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
        }
      } else if (temp==1) {
        printstuff(text, command, "The Machinist looks away. "
         "Smirking the Hermit taps on their forehead. 'It's those goggles. Haven't seen those in a long time. Saying is, "
         "you people don't get buried with 'em. You pick them up from your dead and make them your own. Ain't that right?'\n");
        wclear(command);
        box(command, 0, 0);
        mvwprintw(command,1,1, "Honest(0)");
        mvwprintw(command,2,1, "Indifferent(1)");
        mvwprintw(command,3,1, "Stay Silent(2)");
        wrefresh(command);
        if (temp==2) {
          printstuff(text, command, "The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
        } else if (temp==1) {
          printstuff(text, command, "The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
           "Shrugging the Machinist replies through their scarf 'It is a way of proofing someone's worth and managing ressources. "
           "No point in wasting a pair of perfectly fine goggles.' "
           "They wait for Hermit to answer. Instead they bring their hand to their chin in consideration. "
           "'I find no wrong with that.' they say. \n");
        } else if (temp==0) {
          printstuff(text, command, "The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
           "Shrugging the Machinist tries to put their thoughts to words 'It may not be easy to understand but there are certain ways to "
           "do things in the machinists' community. One grows up fixing things and being taught to fix. One follows the guiding of their teacher, "
           "and the day they die a student who has been taught until that day has proven worthy enough to wear their teacher's goggles and start taking "
           "their own students. One doesn't teach someone not worthy of becoming a machinist. And besides that... "
           "No point in wasting a pair of perfectly fine goggles.' "
           "They wait for Hermit to answer. Instead the strange figure raises their hand to their chin in consideration. "
           "'I find nothing wrong with that.' they say. \n");
        } else {
          printstuff(text, command, "The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
        }
      } else {
        printstuff(text, command, "Reluctant the Machinists avoids the Hermit's looks. It's not their matter who they are. In fact they hadn't even expected company out here. \n");
      }
      printstuff(text, command, "Some time flies by in the pulsating light of the glowcube. This small apparatus should be useless out here. It did not warm them and it wouldn't even "
       "scare predators. Melancholicly the Machinist wonders why it still makes them feel safer in the dark of the Red Wastelands."
       "'So, machinist, what brings you out here to the desert?' they Hermit says.\n");
      wclear(command);
      box(command, 0, 0);
      mvwprintw(command,1,1, "Stubborn(0)");
      mvwprintw(command,2,1, "Honest(1)");
      mvwprintw(command,3,1, "Stay Silent(2)");
      wrefresh(command);
      temp=getText(command,3);
      if (temp==2) {
        printstuff(text, command, "The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
      } else if (temp==1) {
        printstuff(text, command, "The Machinist sighs. What made them trust that strange person enough to keep talking? "
         "'I am looking for something. Something I may or may not have lost. I can neither tell you what it is nor when "
         "I lost it or if it even exists. I apologize if that's not the answer you were hoping for.' "
         "The Hermit chuckles. 'Oh no, quite the contrary. Didn't talked to a living soul for a lifetime. Even though my origins lie in one of the Cities "
         "it couldn't feel more strange to me looking back to that time. So I kinda can relate to having something so dear in your heart while at the same "
         "time not being able to put it into words. "
         "The Machinist, exhausted from a day's journey, looks up. 'You're from one of the Great Cities?' they ask. "
         "'Born and raised there' the hermit announces proudly. 'But one day ol' me figured living in the cage of the city walls ain't the life for me. "
         "There were things still undone, places unseen by me. So I left. Never had any regrets.' "
         "Something of how the stranger said it brought the Machinist back to the day they decided to go onto their journey. Never regreting it would be "
         "a bit far fetched. Staying in the walls of the Great City on the other hand would have meant putting their unknown goal to rest forever.\n ");
        machinistsHeart = true;
      } else if (temp==0) {
        printstuff(text, command, "'Why should that be any of your business?' the Machinist hisses. "
         "The Hermit chuckles. 'Oh no, not the least. Didn't want to insult you or anything. Didn't talk to a living soul for a lifetime. "
         "Even though my origins lie in one of the Cities it couldn't feel more strange to me looking back to that time. "
         "So I kinda can relate to having something so dear in your heart while at the same time not being able to put it into words. "
         "The Machinist, exhausted from a day's journey, looks up. 'You're from one of the Great Cities?' they ask. "
         "'Born and raised there' the hermit announces proudly. 'But one day ol' me figured living in the cage of the city walls ain't the life for me. "
         "There were things still undone, places unseen by me. So I left. And never regreted anything.' "
         "Something of how the stranger said it brought the Machinist back to the day they decided to go onto their journey. Never regreting it would be "
         "a bit far fetched. Staying in the walls of the Great City on the other hand would have meant putting their unknown goal to rest forever.\n ");
        machinistsHeart = true;
      } else {
        printstuff(text, command, "The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
      }
      printstuff(text, command, "The night goes on with the to of them sitting on opposite sides of the glowcube. "
       "Finally, at the last shades of the nightern Wastelands, the Hermit rises wiping away weeks worth of dust and dirt from their trousers. "
       "'So long, friend. I will take my leave. May our next meeting be a pleasant one. But first, forgive me to ask, are their rations you could muster?'\n");
      wclear(command);
      box(command, 0, 0);
      mvwprintw(command,1,1, "Agree(0)");
      mvwprintw(command,2,1, "Deny(1)");
      wrefresh(command);
      temp=getText(command,2);
      if (temp==1) {
        printstuff(text, command, "The Machinist shakes their head. "
         "'Well' the Hermit says 'at least I met someone to kill some time with. Travel well, friend! May your steps take you to what you're looking for!'\n");
        daytime = 1;
      } else if (temp==0
        && nutbar==true
        && bottle==true) {
        printstuff(text, command, "This one is particular. The Machinist nods. Some of their rations they could spare. As they give some Sips of water and some bars to the Hermit "
         "the strange figure's eyes sparkle for a second in something that could have been gratitude. Though the Hermit didn't speak it out loud there is "
         "something about their voice that has changed as they say 'Travel well, friend! May your steps take you to what you're looking for!' "
         "The rising sun at their backs they depart. \n");
        bottle=false;
        nutbar=false;
        int a=getNumber("nutrition bar");
        remove_item(items, a);
        a=getNumber("filled bottle");
        remove_item(items, a);
        Inventory em_bo={"empty bottle", "An empty bottle made from aluminum."};
        add_item(&em_bo);
        show_inventory(items);
        daytime = 1;
        hermitsGratitude = true;
      } else if (temp==0
        && (nutbar || bottle)==false){
        printstuff(text, command, "They wish too share but there is not enough for one person, leave alone two. "
         "So the Machinist shakes their head. "
         "'Well' the Hermit says 'at least I met someone to kill some time with. Travel well, friend! May your steps take you to what you're looking for!'\n");
        daytime = 1;
      }
      hermit = true;
    }
    default:
    temp=1;
    break;
  }   
  gamestate = 1;
  }

  //survivable with crowbar or nutrition bar (and skipping with bottle, didn't fix it yet)
  //else death and ending
  void redBeasts(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time){
  checkForDaytime(time,text,command);
  printstuff(text, command, "A sudden snarl lets the Machinist spin around. Somehow three hound-like creatures managed to sneak up on them. "
   "Their flesh looks swollen on various points, their heads low so their teeth are only barely visible. Even so, caught off guard "
   "the Machinist is certain that would not stop the beasts from ending them in the glimpse of a second. "
   "There is only so much one can do when not trained in fighting. One of the beasts lunges forward. Only by chance the Machinist "
   "reacts in time to jump aside just enough to just feel the gashing pain as something sharp slices their arm. "
   "Looking at the hounds they realize, that their skin is in fact not swollen at all. Somehow someone must have modified these animals "
   "for what they thought was flesh are just great junks of metal sewn into their bodies. For more the Machinist lacks the time. \n");
  mvwprintw(command,1,1, "How shall the Machinist react?");
  mvwprintw(command,2,1, "run(0)");
  mvwprintw(command,3,1, "wait(1)");
  mvwprintw(command,4,1, "use object(2)");
  wrefresh(command);
  int temp=getText(command, 3);
  switch (temp) {
    case 0:
    printstuff(text, command, "As an impulse the Machinist spins around to run. Never known fear they suddenly don't want their search to end. There is so much "
     "they still don't know. Their scarf is blown away as they go ever faster and faster. A shimmer of hope cries in pain as a heavy "
     "body brings them down. Sharp claws tear through their clothing, piercing into their skin. A snarl, then another. Thoughts build in the "
     "Machinist's head of what they could do next. In vain. Powerful jaws seize their neck. There is pain. Then there is nothing anymore.\n");
    gamestate = 3;
    break;
    case 1:
    printstuff(text, command, "Slowly the Machinist raises their hands in an attempt to calm the vicious animals before them. Their breath slows down. This could work. "
     "Before they get a chance to realize it one of the beast brings them down with its heavy body. Caught in their bite the Machinist gets trown "
     "further over the harsh ground. Their head hits something for their vision goes blurry and there is a crack now in their goggles. "
     "Sharp claws tear through their clothing, piercing into their skin. A snarl, then another. Thoughts build in the "
     "Machinist's head of what they could do next. In vain. Powerful jaws seize their neck. There is pain. Then there is nothing anymore.\n");
    gamestate = 3;
    break;
    case 2: // just with items from Chunkyards survivable
    wclear(command);
    box(command, 0, 0);
    mvwprintw(command,1,1,"There is not much time, if any. Perhaps one of these items could be put to use");
    wrefresh(command);
    useItem(items, text, command, time);
    daytime++;
    gamestate = 1;
    break;        
  }
  }

  //three different endings depending on hermit and hermitsGratitude
  void clockworkHydra(WINDOW*command, WINDOW *text, WINDOW *items, WINDOW *time){
  checkForDaytime(time,text,command);
  wclear(command);
  box(command, 0, 0);
  wclear(text);
  printstuff(text, command, "A sudden tremor in the ground leaves the Machinist shaking. Unexpected, but the goal of their journey all the same. "
   "It takes some time to make out the gargantuan sillhouette in the far distance and even more time to distiguish each of the creature's "
   "heads from each other. Approximatly half a mile from the Machinist the monster stops moving as if searching for something. The only noise remaining "
   "is the sound of a thousand shifting gears everturning around themselves. It doesn't take an expert's word to see that what's opposite them is some kind "
   "of mechanical hydra. Seven heads twisting and turning, blind for the sun or the moon or even the ground on which they are walking. It is said the hydra "
   "is roaming the outer regions in the search for something. Perhaps prey, perhaps a place to finally break down because its creator died long time ago. "
   "A earshattering, unearthly roar errupts from its heads, each one a little delayed, sounding like seven great machines crashed into each other. "
   "This is clearly something out of the ordinary, for sure. But what should one do, being faced with a creature like that?"
   "A unknown longing spreads in the Machinist's chest as if they had forgotten about something.");
  mvwprintw(command,1,1, "There are some options:");
  mvwprintw(command,2,1, "run(0)");
  mvwprintw(command,3,1, "wait(1)");
  mvwprintw(command,4,1, "approach(2)");
  int temp=getText(command, 3);
  switch (temp) {
    case 0:
    printstuff(text,command, "Whatever that feeling is. It's certainly not the need to be crushed by a sixty feet tall monster. "
      "Better to get some ground now and find out another day.");
    hydra=true;
    daytime++;
    gamestate = 1;
    break;
    case 1:
    printstuff(text,command, "The Machinist freezes in shock. Even if they ran now the beast would be faster for sure. Maybe they had a chance when being still for a few minutes. "
     "First nothing happens, then after ten minutes or so life returns to the monstrous body and it slowly moves into an other direction and away. "
     "The Machinist remains for some time longer to be sure before they depart as well.");
    hydra=true;
    daytime++;
    gamestate = 1;
    break;
    case 2  :
    if (machinistsHeart == true) {
      printstuff(text,command, "Even though the Machinist started their journey without any reason known to them, out of an impulse really, suddenly they know with a great certainty "
       "that this is the place and time that they are meant to be. Coming closer the great beast notices the small humanoid. First it is only one head that's "
       "lowered by the countless cogs stretching all over its body. Breathless its maw opens before the Machinist's face in a silent roar. When they don't move "
       "it closes again and another head makes its way down and another and another, until seven deadly, rusted, snake-like heads are resting in the air close to "
       "the ground. \n"
       "'We know you' they seem to say. And the Machinist feels like remembering something, too. What it is they cannot say. But it is what brought them here. "
       "They feel the connection to this legendary being in an instant like to a creation of their own design.\n"
       "The words of the Hermit echo in their mind and suddenly they know what to do.\n"
       "Wordless they let their coat fall to the ground, letting the air touch their skin, more metal than flesh in the resent years, for the first time in ages. \n"
       "'This is for you' they mumble through their scarf and open their chest, revealing an old, worn pump layered with cracking and scratching cogwheels. "
       "Ripping out their very own heart another whisper escapes their lips nothing more than a powerless breeze. 'It's yours.' \n"
       "The Machinist manages to hold their balance just long enough for the hydra to pick it up gently with one of its maws, before they collapse. \n"
       "Stripped of their heart, at the end of their journey, the Machinist crawls to a near rock to pull themselves into a sitting position. "
       "It is done.\n");
      gamestate = 3;
    } else {
      printstuff(text,command, "Even though the Machinist started their journey without any reason known to them, out of an impulse really, suddenly they know with a great certainty "
       "that this is the place and time that they are meant to be. Coming closer the great beast notices the small humanoid. First it is only one head that's "
       "lowered by the countless cogs stretching all over its body. Breathless its maw opens before the Machinist's face in a silent roar. When they don't move "
       "it closes again and another head makes its way down and another and another, until seven deadly, rusted, snake-like heads are resting in the air close to "
       "the ground. \n"
       "'We know you' they seem to say. And the Machinist feels like remembering something, too. What it is they cannot say. But it is what brought them here. "
       "They feel the connection to this legendary being in an instant like to a creation of their own design.\n"
       "There is nothing more their mind can come up with, before one of the heads lashes out in a high scream pulling them into a tight bite. "
       "The hydra throws them into the air for the other heads to rip the Machinist to pieces. Not for devouring, no. The Clockwork Hydra is waiting for something... "
       "or someone. Perhaps the Machinist, now lying in the dirt stripped of every life, had been that someone, but how should the hydra know or care? \n"
       "No more reason to remain the great beast walks away, its every step shaking the earth, leaving only behind the remains of a shattered soul and their broken body.\n");
      gamestate = 3;
    }
  }
  }
