import java.util.ArrayList;

import java.util.HashMap;
import java.util.StringTokenizer;
import java.io.BufferedReader;
import java.io.FileReader;

import acm.program.ConsoleProgram;
import sun.applet.*;

public class TheMachinist extends ConsoleProgram {
	private ArrayList<String> inventory = new ArrayList<String>();
	private HashMap<String, ArrayList<String>> countryMap = new HashMap<String, ArrayList<String>>();
	int wSizeX = 1500;
	int wSizeY = 1000;
	private int daytime = 2;
	private String answer;
	private String currentLocation;
	private boolean gamemode = true;
	private int gamestate = 1;
	private boolean hermit = false;
	private boolean machinistsHeart = false;
	private boolean hermitsGratitute = false;

	public void run() {
		setup();
		introScreen();
		while (gamemode == true) {
			if (gamestate == 1) {
				startJourney();
			} else if (gamestate == 2) {
				events();
			} else if (gamestate == 3) {
				ending();
				gamemode = false;
			}
		}
		println("\n" + "\n" + "\n"
				+ "Though it is not much, thank you for playing!\n" + ">(.^.)<");
	}

	private void startJourney() {
		while (gamestate == 1) {
			if(daytime>0){
			checkForDaytime();
			}
			if (gamestate != 1)// nach Ver�nderung des gamestates in
								// checkForDaytime() Abbruch der Methode zur
								// Auswahl einer anderen
				break;
			checkForAction();
		}
	}

	private void setup() {
		currentLocation = "RedWastelands";
		setSize(wSizeX, wSizeY);
		setFont("Arial-bold-24");

		inventory.add("worn goggles"); // F�llen des Inventars
		inventory.add("Machinist's tools");
		inventory.add("scarf");
		inventory.add("filled bottle");
		inventory.add("glowcube");
		analyseLayout(); // Lesen der locations.txt Datei
		// printMap();
	}

	private void events() { // Beschreibung der drei m�glichen Events nach
							// Bedingung
		if (currentLocation.equals("RedWastelands") && daytime == 3) {
			theHermit();
		} else if (currentLocation.equals("RedWastelands") && daytime == 0) {
			redBeasts();
		} else if (currentLocation.equals("TheGreatBeyond") && (daytime == 3|| daytime ==0)) {
			clockworkHydra();
		}
	}

	private void redBeasts() { // Event nachts in den Red Wastelands
		println("A sudden snarl lets the Machinist spin around. Somehow three hound-like creatures managed to sneak up on them. "
				+ "Their flesh looks swollen on various points, their heads low so their teeth are only barely visible. Even so, caught off guard "
				+ "the Machinist is certain that would not stop the beasts from ending them in the glimpse of a second. "
				+ "There is only so much one can do when not trained in fighting. One of the beasts lunges forward. Only by chance the Machinist "
				+ "reacts in time to jump aside just enough to just feel the gashing pain as something sharp slices their arm. "
				+ "Looking at the hounds they realize, that their skin is in fact not swollen at all. Somehow someone must have modified these animals "
				+ "for what they thought was flesh are just great junks of metal sewn into their bodies. For more the Machinist lacks the time. \n");
		answer = readLine("How shall the Machinist react? [run, wait, use object] ");
		switch (answer) {
		case "run":
			println("As an impulse the Machinist spins around to run. Never known fear they suddenly don't want their search to end. There is so much "
					+ "they still don't know. Their scarf is blown away as they go ever faster and faster. A shimmer of hope cries in pain as a heavy "
					+ "body brings them down. Sharp claws tear through their clothing, piercing into their skin. A snarl, then another. Thoughts build in the "
					+ "Machinist's head of what they could do next. In vain. Powerful jaws seize their neck. There is pain. Then there is nothing anymore.\n");
			gamestate = 3;
			break;
		case "wait":
			println("Slowly the Machinist raises their hands in an attempt to calm the vicious animals before them. Their breath slows down. This could work. "
					+ "Before they get a chance to realize it one of the beast brings them down with its heavy body. Caught in their bite the Machinist gets trown "
					+ "further over the harsh ground. Their head hits something for their vision goes blurry and there is a crack now in their goggles. "
					+ "Sharp claws tear through their clothing, piercing into their skin. A snarl, then another. Thoughts build in the "
					+ "Machinist's head of what they could do next. In vain. Powerful jaws seize their neck. There is pain. Then there is nothing anymore.\n");
			gamestate = 3;
			break;
		case "use object": // kann nur mit den Items �berlebt werden, die man in
							// den Chunkyards finden kann
			answer = readLine("There is not much time, if any. Perhaps one of these items could be put to use: "
					+ inventory);
			switch (answer) {
			case "nutrition bars":
				println("Probably the only thing these hounds want is not to starve. They would be left without food, but be torn to shreds by some grotesque animals "
						+ "as hardly better. Slowly reaching into their bag the machinist picks the nutrition bars they... found... at the Chunkyards and throws them toward "
						+ "the beast as they spin around and run. Their boots are sounding unbearably loud with every step. Against all odds their plan must have worked because of "
						+ "the lack of animal teeth in the Machinist's flesh. Even so they don't stop running until their muscles and lunges protest in pain. Turning around they only "
						+ "see the empty red of the Red Wastelands.\n");
				inventory.remove("nutrition bars");
				daytime++;
				gamestate = 1;
				break;
			case "crowbar":
				println("Sometimes there are no other options left than violence. Even for a simple machinist. Sometimes the only option is to use a crowbar to defend one's life. "
						+ "And 'sometimes' means know. As the first of the beast lunges toward the Machinist they bring down their improvised weapon with a heavy blow, hearing the"
						+ "whincing of a hurt animal, breaking of bones and the ringing of metal against metal. That wasn't so difficult after all. Bringing themselves into some kind of ready position the"
						+ "beasts start to circle them snarling. Once more the Machinist lashes out with the crowbar, connecting to the shoulder of the know more cautious hound. "
						+ "They remain like that for a minute, neither of them really sure how to react. Then with a painfull bark the beasts retreat into the distance.\n");
				daytime++;
				gamestate = 1;
				break;
			default:
				println("Before the Machinist can decide one of the beast brings them down with its heavy body. Caught in their bite the Machinist gets trown "
						+ "further over the harsh ground. Their head hits something for their vision goes blurry and there now is a crack in their goggles. "
						+ "Sharp claws tear through their clothing, piercing into their skin. A snarl, then another. Thoughts build in the "
						+ "Machinist's head of what they could do next. In vain. Powerful jaws seize their neck. There is pain. Then there is nothing anymore.\n");
				gamestate = 3;
				break;
			}

		}
	}

	private void theHermit() { // Wenn mit ihm gesprochen wird, Schalten von
								// Machinist's Heart auf "true" --> drittes Ende
								// in The Great Beyond, bei Teilen viertes Ende
		println("Looking around the Machinist notices a hooded figure approaching in the distance. "
				+ "The shrug. Unusual to meet another soul out here. Most of all now that the sun is sinking. "
				+ "No one in there right mind would stay out here at night. The irony of that statement doesn't escape the Machinist.\n");
		answer = readLine("What shall the Machinist do? [leave, wait] ");
		switch (answer) {
		case "leave":
			daytime++;
			break;
		case "wait":
			println("Waiting for the person to approach the Machinist chooses a lean rock formation to build their camp for the night. Pulling out their glowcube a shimmer "
					+ "of warm light engulfes them and the surrounding area. Hopefully the rocks are enough of a shelter to not attract any predators. "
					+ "As the stranger comes closer more gets visible of their crooked form. There is nothing worth mentioning about them. "
					+ "Their smile reveals a set of sand coloured teeth that glimmer like gold and their skin bears the mark of age and the rough climate of the outer regions, "
					+ "making it impossible to determine the gender of the person. Not that it would change anything.\n");
			if (hermit == true) {
				println("'It's good to see you, friend. How have you been since the last time? Care to share meal and supplies?' \n");
			} else {
				println("'That's an unfamiliar face for ya! Night's gonna get dark and me's not to thrilled to find out what's out there. "
						+ "Allright for me to stay here for some time?'\n");
			}
			answer = readLine("How shall the Machinist react? [accept, decline] ");
			switch (answer) {
			case "decline":
				println("The stranger looks at them in a combination of sadness and understanding. They slowly nod. "
						+ "'I see. Dangerous as it is out here I wouldn't trust some hermit either. Fare well then! And may our next meeting be a pleasant one!' "
						+ "As if they had been a mere dream the Hermit fades back into the shadows, leaving the Machinist on their own on the hard grounds of the Red Wastelands. \n");
				gamestate = 1;
				break;
			default:
				answer = "accept";
			case "accept":
				println("Indifferent the Machinist gestures to the stranger to sit opposite them who then follows. "
						+ "The stranger, perhaps one of the rare, but somehow famous hermits studies the glowcube for a while as if reminiscing. "
						+ "'So' they say, 'You're one of them machinists, aren't you?\n");
				answer = readLine("[sarcastic / nod / stay silent] ");
				
				if (answer.equals("stay silent")) {
					println("Reluctant the Machinists avoids the Hermit's looks. It's not their matter who they are. In fact they hadn't even expected company out here. \n");
				} else if (answer.equals("sarcastic")) {
					println("The Machinist growls. 'What gave it away?' "
							+ "Smirking the Hermit taps on their forehead. 'It's those goggles. Haven't seen those in a long time. Saying is, "
							+ "you people don't get buried with 'em. You pick them up from your dead and make them your own. Ain't that right?'\n");
					answer = readLine("[honest / indifferent / stay silent] ");
					if (answer == "stay silent") {
						println("The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
					} else if (answer.equals("indifferent")) {
						println("The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
								+ "Shrugging the Machinist replies through their scarf 'It is a way of proofing someone's worth and managing ressources. "
								+ "No point in wasting a pair of perfectly fine goggles.' "
								+ "They wait for Hermit to answer. Instead they bring their hand to their chin in consideration. "
								+ "'I find no wrong with that.' they say. \n");
					} else if (answer.equals("honest")) {
						println("The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
								+ "Shrugging the Machinist tries to put their thoughts to words 'It may not be easy to understand but there are certain ways to "
								+ "do things in the machinists' community. One grows up fixing things and being taught to fix. One follows the guiding of their teacher, "
								+ "and the day they die a student who has been taught until that day has proven worthy enough to wear their teacher's goggles and start taking "
								+ "their own students. One doesn't teach someone not worthy of becoming a machinist. And besides that... "
								+ "No point in wasting a pair of perfectly fine goggles.' "
								+ "They wait for Hermit to answer. Instead they bring their hand to their chin in consideration. "
								+ "'I find no wrong with that.' they say. \n");
					} else {
						println("The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
					}
				} else if (answer.equals("nod")) {
					println("The Machinist looks away. "
							+ "Smirking the Hermit taps on their forehead. 'It's those goggles. Haven't seen those in a long time. Saying is, "
							+ "you people don't get buried with 'em. You pick them up from your dead and make them your own. Ain't that right?'\n");
					answer = readLine("[honest / indifferent / stay silent] ");
					if (answer == "stay silent") {
						println("The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
					} else if (answer.equals("indifferent")) {
						println("The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
								+ "Shrugging the Machinist replies through their scarf 'It is a way of proofing someone's worth and managing ressources. "
								+ "No point in wasting a pair of perfectly fine goggles.' "
								+ "They wait for Hermit to answer. Instead they bring their hand to their chin in consideration. "
								+ "'I find no wrong with that.' they say. \n");
					} else if (answer.equals("honest")) {
						println("The Hermit was not wrong but phrasing their traditions like that made them sound weird. "
								+ "Shrugging the Machinist tries to put their thoughts to words 'It may not be easy to understand but there are certain ways to "
								+ "do things in the machinists' community. One grows up fixing things and being taught to fix. One follows the guiding of their teacher, "
								+ "and the day they die a student who has been taught until that day has proven worthy enough to wear their teacher's goggles and start taking "
								+ "their own students. One doesn't teach someone not worthy of becoming a machinist. And besides that... "
								+ "No point in wasting a pair of perfectly fine goggles.' "
								+ "They wait for Hermit to answer. Instead they bring their hand to their chin in consideration. "
								+ "'I find no wrong with that.' they say. \n");
					} else {
						println("The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
					}
				} else {
					println("Reluctant the Machinists avoids the Hermit's looks. It's not their matter who they are. In fact they hadn't even expected company out here. \n");
				}
				println("Some time flies by in the pulsating light of the glowcube. This small apparatus should be useless out here. It did not warm them and it wouldn't even "
						+ "scare predators. Melancholicly the Machinist wonders why it still makes them feel safer in the dark of the Red Wastelands."
						+ "'So, machinist, what brings you out here to the desert?' they Hermit says.\n");
				answer = readLine("[stubborn / honest / stay silent] ");
				if (answer.equals("stay silent")) {
					println("The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
				} else if (answer.equals("honest")) {
					println("The Machinist sighs. What made them trust that strange person enough to keep talking? "
							+ "'I am looking for something. Something I may or may not have lost. I can neither tell you what it is nor when "
							+ "I lost it or if it even exists. I apologize if that's not the answer you were hoping for.' "
							+ "The Hermit chuckles. 'Oh no, quite the contrary. Didn't talked to a living soul for a lifetime. Even though my origins lie in one of the Cities "
							+ "it couldn't feel more strange to me looking back to that time. So I kinda can relate to having something so dear in your heart while at the same "
							+ "time not being able to put it into words. "
							+ "The Machinist, exhausted from a day's journey, looks up. 'You're from one of the Great Cities?' they ask. "
							+ "'Born and raised there' the hermit announces proudly. 'But one day ol' me figured living in the cage of the city walls ain't the life for me. "
							+ "There were things still undone, places unseen by me. So I left. And never regreted anything.' "
							+ "Something of how the stranger said it brought the Machinist back to the day they decided to go onto their journey. Never regreting it would be "
							+ "a bit far fetched. Staying in the walls of the Great City on the other hand would have meant putting their unknown goal to rest forever.\n ");
					machinistsHeart = true;
				} else if (answer.equals("stubborn")) {
					println("'Why should that be any of your business?' they Machinist hisses. "
							+ "The Hermit chuckles. 'Oh no, not the least. Didn't want to insult you or anything. Didn't talk to a living soul for a lifetime. "
							+ "Even though my origins lie in one of the Cities it couldn't feel more strange to me looking back to that time. "
							+ "So I kinda can relate to having something so dear in your heart while at the same time not being able to put it into words. "
							+ "The Machinist, exhausted from a day's journey, looks up. 'You're from one of the Great Cities?' they ask. "
							+ "'Born and raised there' the hermit announces proudly. 'But one day ol' me figured living in the cage of the city walls ain't the life for me. "
							+ "There were things still undone, places unseen by me. So I left. And never regreted anything.' "
							+ "Something of how the stranger said it brought the Machinist back to the day they decided to go onto their journey. Never regreting it would be "
							+ "a bit far fetched. Staying in the walls of the Great City on the other hand would have meant putting their unknown goal to rest forever.\n ");
					machinistsHeart = true;
				} else {
					println("The Hermit shrugs. 'Don't need to answer that. Just ol' me just asking.'\n");
				}
				println("They night goes on with the to of them sitting on opposite sides of the glowcube. "
						+ "Finally, at the last shades of the nightern Wastelands, the Hermit rises wiping away weeks worth of dust and dirt from their trousers. "
						+ "'So long, friend. I will take my leave. May our next meeting be a pleasant one. But first, forgive me to ask, are their rations you could muster?'\n");
				answer = readLine("[agree / deny]");
				if (answer.equals("deny")) {
					println("The Machinist shakes their head. "
							+ "'Well' the Hermit says 'at least I met someone to kill some time with. Travel well, friend! May your steps take you to what you're looking for!'\n");
					daytime = 1;
				} else if (answer.equals("agree")
						&& inventory.contains("nutrition bars")
						&& inventory.contains("filled bottle")) {
					println("This one is particular. The Machinist nods. Some of their rations they could spare. As they give some Sips of water and some bars to the Hermit "
							+ "the strange figure's eyes sparkle for a second in something that could have been gratitude. Though the Hermit didn't speak it out loud there is "
							+ "something about their voice that has changed as they say 'Travel well, friend! May your steps take you to what you're looking for!' "
							+ "The rising sun at their backs they depart. \n");
					daytime = 1;
					hermitsGratitute = true;
				} else {
					println("They wish too share but there is not enough for one person, leave alone too. "
							+ "So the Machinist shakes their head. "
							+ "'Well' the Hermit says 'at least I met someone to kill some time with. Travel well, friend! May your steps take you to what you're looking for!'\n");
					daytime = 1;
				}
				hermit = true;
			}
		default:
			answer = "wait";
			break;
		}		
		gamestate = 1;
	}

	private void clockworkHydra() {// kann mit Machinist's Heart zum Ende f�hren
									// oder bei nicht Ann�herung �berlebt werden
		println("A sudden tremor in the ground leaves the Machinist shaking. Unexpected, but the goal of their journey all the same. "
				+ "It takes some time to make out the gargantuan sillhouette in the far distance and even more time to distiguish each of the creature's "
				+ "heads from each other. Approximatly half a mile from the Machinist the monster stops moving as if searching for something. The only noise remaining "
				+ "is the sound of a thousand shifting gears everturning around themselves. It doesn't take an expert's word to see that what's opposite them is some kind "
				+ "of mechanical hydra. Seven heads twisting and turning, blind for the sun or the moon or even the ground on which they are walking. It is said the hydra "
				+ "is roaming the outer regions in the search for something. Perhaps prey, perhaps a place to finally break down because its creator died long time ago. "
				+ "A earshattering, unearthly roar errupts from its heads, each one a little delayed, sounding like seven great machines crashed into each other. "
				+ "This is clearly something out of the ordinary, for sure. But what should one do, being faced with a creature like that?\n");
		answer = readLine("A unknown longing spreads in the Machinist's chest as if they had forgotten about something. There are some options: [run, wait, approach]");
		switch (answer) {
		case "run":
			println("Whatever that feeling is. It's certainly not the need to be crushed by a sixty feet tall monster. Better to get some ground now and find out another day.\n");
			answer = readLine("Where to run?" + countryMap.get(currentLocation));
			currentLocation = answer;
			daytime++;
			gamestate = 1;
			break;
		case "wait":
			println("The Machinist freezes in shock. Even if they ran now the beast would be faster for sure. Maybe they had a chance when being still for a few minutes. "
					+ "First nothing happens, then after ten minutes or so life returns to the monstrous body and it slowly moves into an other direction and away. "
					+ "The Machinist remains for some time longer to be sure before they depart as well.");
			daytime++;
			gamestate = 1;
			break;
		case "approach":
			if (machinistsHeart == true) {
				println("Even though the Machinist started their journey without any reason known to them, out of an impulse really, suddenly they know with a great certainty "
						+ "that this is the place and time that they are meant to be. Coming closer the great beast notices the small humanoid. First it is only one head that's "
						+ "lowered by the countless cogs stretching all over its body. Breathless its maw opens before the Machinist's face in a silent roar. When they don't move "
						+ "it closes again and another head makes its way down and another and another, until seven deadly, rusted, snake-like heads are resting in the air close to "
						+ "the ground. \n"
						+ "'We know you' they seem to say. And the Machinist feels like remembering something, too. What it is they cannot say. But it is what brought them here. "
						+ "They feel the connection to this legendary being in an instant like to a creation of their own design.\n"
						+ "The words of the Hermit echo in their mind and suddenly they know what to do.\n"
						+ "Wordless they let their coat fall to the ground, letting the air touch their skin, more metal than flesh in the resent years, for the first time in ages. \n"
						+ "'This is for you' they mumble through their scarf and open their chest, revealing an old, worn pump layered with cracking and scratching cogwheels. "
						+ "Ripping out their very own heart another whisper escapes their lips nothing more than a powerless breeze. 'It's yours.' \n"
						+ "The Machinist manages to hold their balance just long enough for the hydra to pick it up gently with one of its maws, before they collapse. \n"
						+ "Stripped of their heart, at the end of their journey, the Machinist crawls to a near rock to pull themselves into a sitting position. "
						+ "It is done.\n");
				gamestate = 3;
			} else {
				println("Even though the Machinist started their journey without any reason known to them, out of an impulse really, suddenly they know with a great certainty "
						+ "that this is the place and time that they are meant to be. Coming closer the great beast notices the small humanoid. First it is only one head that's "
						+ "lowered by the countless cogs stretching all over its body. Breathless its maw opens before the Machinist's face in a silent roar. When they don't move "
						+ "it closes again and another head makes its way down and another and another, until seven deadly, rusted, snake-like heads are resting in the air close to "
						+ "the ground. \n"
						+ "'We know you' they seem to say. And the Machinist feels like remembering something, too. What it is they cannot say. But it is what brought them here. "
						+ "They feel the connection to this legendary being in an instant like to a creation of their own design.\n"
						+ "There is nothing more their mind can come up with, before one of the heads lashes out in a high scream pulling them into a tight bite. "
						+ "The hydra throws them into the air for the other heads to rip the Machinist to pieces. Not for devouring, no. The Clockwork Hydra is waiting for something... "
						+ "or someone. Perhaps the Machinist, now lying in the dirt stripped of every life, had been that someone, but how should the hydra know or care? \n"
						+ "No more reason to remain the great beast walks away, its every step shaking the earth, leaving only behind the remains of a shattered soul and their broken body.\n");
				gamestate = 3;
			}
		}
	}

	private void ending() { // Je nach Endbedingung Einlesen verschiedener
							// Textdateien
		String thisLine = null;
		try {
			if (currentLocation.equals("TheGreatCity")) {
				BufferedReader br = new BufferedReader(new FileReader(
						"staticEnding.txt"));
				while ((thisLine = br.readLine()) != null) {
					println(thisLine);
				}
			} else if ((currentLocation.equals("TheGreatBeyond") && machinistsHeart == false)
					|| currentLocation.equals("RedWastelands")) {
				BufferedReader br = new BufferedReader(new FileReader(
						"shatteredEnding.txt"));
				while ((thisLine = br.readLine()) != null) {
					println(thisLine);
				}
			} else if (currentLocation.equals("TheGreatBeyond")
					&& machinistsHeart == true && hermitsGratitute == false) {
				BufferedReader br = new BufferedReader(new FileReader(
						"lostCreationEnding.txt"));
				while ((thisLine = br.readLine()) != null) {
					println(thisLine);
				}
			} else if (currentLocation.equals("TheGreatBeyond")
					&& machinistsHeart == true && hermitsGratitute == true) {
				BufferedReader br = new BufferedReader(new FileReader(
						"theMachinistsBequest.txt"));
				while ((thisLine = br.readLine()) != null) {
					println(thisLine);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// private void printMap() {
	// for (String key : countryMap.keySet()) {
	// ArrayList<String> places = countryMap.get(key);
	// println(key + " > " + places);
	// }
	// }

	private void checkForDaytime() {// Je nach Tageszeit und Ort verschiedene
									// Texte
		switch (daytime) {
		case 0: // night
			println("NIGHT\n");
			switch (currentLocation) {
			case "TheGreatCity":
				println("The lights of the neversleeping city welcome the Machinist like a blanket made from warmth. "
						+ "As the metal doors are closing behind a turmoil of voices and hammering steel, of screaming pipes and blazing furnaces engulf them. "
						+ "What is so notable about the outside anyway? "
						+ "Anonymous faces, wearing masks or goggles, greet the Machinist as if they had never been away. "
						+ "There is no regret about leaving the world to rot outside the safe city walls. "
						+ "After all, there are apparatus to construct, failures to fix. There has never been a point in it in the first place. "
						+ "Indifferent the Machinist sheds their tools on a simple working table, considering the rusted pair of tongs with an ineffable yearning. Then, they put the thougt aside. "
						+ "There is so much work to do. "
						+ "And scant time. \n");
				gamestate = 3;
				break;
			case "RedWastelands":
				println("The heat of a day's scorching sun is still lingering on the now more dirty than red looking sands of the Red Wastelands. "
						+ "Even so, the sher lack of direct sunlight makes traveling at night a little more sufferable.\n");
				gamestate = 2;
				break;
			case "AcidWastes":
				println("There is nothing pleasant about the Acid Wastes. Not at day, even less at night, for the starless sky makes orientating nearly impossible. "
						+ "If you are lucky the subtle glow of the acid pools warns you of the immenent danger. If not, well, not all pools are glowing. "
						+ "At least the smell is not as bad as usual.\n");
				break;
			case "HowlingCliffs":
				println("Freezing winds are howling, grasping, tearing on the Machinist's gear. Narrow passages lead from the Great City all the way around the Red Wasteland and the Acid Wastes to the Great Beyond. "
						+ "No matter the time of the day, it seems as if the storms hiding in the deep beneath the passes try to drag one down with them. It is said, that the Howling Cliffs once bordered to a massive ocean of sparkling azure water. "
						+ "Now however the Machinist doubts that anyone can even describe what kind of colour azure is supposed to be. \n");
				break;
			case "BoilingLakes":
				println("If one talks about 'the wild' one mostly describes the Boiling Lakes as they are one of the few places to find water. "
						+ "Only problem is, the geysirs and volcanic activities in the area make the process of filling it into some kind of vessel extremely dangerous. "
						+ "For some reason however the lakes cool down at night just enough for living things to drink.\n");
				break;
			case "TheGreatBeyond":
				println("Miles over miles of deserted space unfold before the Machinist, revealing the mythical lands of the Great Beyond. "
						+ "No one knows what's on the other end of the seemingly endless desert. On the other hand considering what one can find in these lands it isn't really tempting to find out. "
						+ "Stories speak of it as endless fields of grass, rich with life and rich with light. "
						+ "Of trees mildly shaking in the wind, of birds singing in all the tongues of the sky. "
						+ "For a short second the Machinist is reminded of that stories, then they realize that even the last person believing in them is long dead. "
						+ "Before them lies only a vast field of nothing, painted blue by the distant light of stars that were too slow to hide from what is left on this rock.\n");
				gamestate = 2;
				break;
			case "TheChunkyards":
				println("Day and night, there is never a time when the Chunkyards of the Great City lie silent. Perhaps it is the fear for what happens when all is quiet, perhaps the constant struggle for resources. "
						+ "It doesn't matter. Something about the screeching of scrap metal reminds the Machinist of a time long forgotten. Unable to fully grasp it or let it go they remain standing amidst the mountains of trash. "
						+ "Just as they consider to leave, a thin beam of light errupts from between the clouds. Just for a moment something like a feeling stirs from behind their mind, then it ceases again. "
						+ "There is no time for that kind of thoughts.\n");
				break;
			}
			break;
		case 1: // morning
			println("SUNRISE\n");
			switch (currentLocation) {
			case "TheGreatCity":
				println("Approaching the Great City a fragile shimmer of the elsewhise hidden morning sun breaks through, illuminating the aeon aged walls in a long dead memory. "
						+ "As the metal doors are closing behind a turmoil of voices and hammering steel, of screaming pipes and blazing furnaces engulf them. "
						+ "What is so notable about the outside anyway? "
						+ "Anonymous faces, wearing masks or goggles, greet the Machinist as if they had never been away. "
						+ "There is no regret about leaving the world to rot outside the safe city walls. "
						+ "After all, there are apparatus to construct, failures to fix. There has never been a point in it in the first place. "
						+ "Indifferent the Machinist sheds their tools on a simple working table, considering the rusted pair of tongs with an ineffable yearning. Then, they put the thougt aside. "
						+ "There is so much work to do. "
						+ "And scant time. \n");
				gamestate = 3;
				break;
			case "RedWastelands":
				println("A shy sun is rising behind layers of greyish clouds as if it was to proud to show itself to the world. "
						+ "Probably better that way, considering the aggressive light it sheds on the living.\n");
				break;
			case "AcidWastes":
				println("There is nothing pleasant about the Acid Wastes. Only a mad one would let themselves be fooled when they lie eyes upon the sparkling acid mists in the morning sun."
						+ "Hundrets over hundrets of ponds filled with deadly liquids extend over miles before the Machinist."
						+ "Even now the stench of methan and sulfur climb into their nose.\n");
				break;
			case "HowlingCliffs":
				println("Dusty winds from beyond the abrupt slash that divides the country in the middle are howling, grasping, tearing on the Machinist's gear. Narrow passages lead from the Great City all the way around the Red Wasteland and the Acid Wastes to the Great Beyond. "
						+ "No matter the time of the day, it seems as if the storms hiding in the deep beneath the passes try to drag one down with them. It is said, that the Howling Cliffs once bordered to a massive ocean of sparkling azure water. "
						+ "Now however the Machinist doubts that anyone can even describe what kind of colour azure is supposed to be. "
						+ "Even so, when one focuses their goggle's lenses they could catch a glimpse of the divide's other side.\n");
				break;
			case "BoilingLakes":
				println("If one talks about 'the wild' one mostly describes the Boiling Lakes as they are one of the few places to find water. "
						+ "Only problem is, the geysirs and volcanic activities in the area make the process of filling it into some sort of vessel extremely dangerous. "
						+ "Seemingly at random fontains of boiling water errupt from holes around the area, changing traversing the Boiling Lakes into a gamble for life every time.\n");
				break;
			case "TheGreatBeyond":
				println("Miles over miles of deserted space unfold before the Machinist, revealing the mythical lands of the Great Beyond. "
						+ "No one knows what's on the other end of the seemingly endless desert. On the other hand considering what one can find in these lands it isn't really tempting to find out. "
						+ "Stories speak of it as endless fields of grass, rich with life and rich with light. "
						+ "Of trees mildly shaking in the wind, of birds singing in all the tongues of the sky. "
						+ "For a short second the Machinist is reminded of that stories, then they realize that even the last person believing in them is long dead. "
						+ "Rising sunlight reveals even more of the vast dessert. "
						+ "In a few hours the heat will have changed the plain into a burning death trap. Who would be so mad to walk this sands in bright daylight?\n");
				break;
			case "TheChunkyards":
				println("Day and night, there is never a time when the Chunkyards of the Great City lie silent. Perhaps it is the fear for what happens when all is quiet, perhaps the constant struggle for resources. "
						+ "It doesn't matter. Something about the screeching of scrap metal reminds the Machinist of a time long forgotten. Unable to fully grasp it or let it go they remain standing amidst the mountains of trash. "
						+ "Slowly the sounds from the Great City swell. The machinists wake. Better not to risk a meeting.\n");
				break;
			}
			break;
		case 2: // noon
			println("SUN'S ZENIT\n");	
			switch (currentLocation) {
			case "TheGreatCity":
				println("Unforgiving the everburning, everhidden sun casts its silent judgement on the lost souls, still stranded in life. "
						+ "Smoke rises from the thousands of chimneys of the Great City while the sound of the never resting machinery halls over the empty plain. "
						+ "As the metal doors are closing behind a turmoil of voices and hammering steel, of screaming pipes and blazing furnaces engulf them. "
						+ "What is so notable about the outside anyway? "
						+ "Anonymous faces, wearing masks or goggles, greet the Machinist as if they had never been away. "
						+ "There is no regret about leaving the world to rot outside the safe city walls. "
						+ "After all, there are apparatus to construct, failures to fix. There has never been a point in it in the first place. "
						+ "Indifferent the Machinist sheds their tools on a simple working table, considering the rusted pair of tongs with an ineffable yearning. Then, they put the thougt aside. "
						+ "There is so much work to do. "
						+ "And scant time. \n");
				gamestate = 3;
				break;
			case "RedWastelands":
				println("The few hours of daylight were just enough to change the red desert into an unforgiving furnace that is burning the still left rest of flesh away. No man, no animal, "
						+ "not even a machine is mad enough to walk the Red Wastelands in bright daylight. Surely the Machinist must have gone mad.\n");
				break;
			case "AcidWastes":
				println("There is nothing pleasant about the Acid Wastes. In the heat of day the ground is constantly heating up, amplifying the smell of dozents of different gases even more. "
						+ "If there was still something like that, one would compare the picture of the countless misty ponds to paintings of hell. "
						+ "But there are no painters left, and the only demons here are human.\n");
				break;
			case "HowlingCliffs":
				println("As the sun is nearing its zenit in the clouded sky the Machinist realizes that the Howling Cliffs prove the theory of all simple things: "
						+ "no one ever wastes a thought considering basic things. Water, air, food. No one thinks about that unless they have to less or to much of it. "
						+ "Cruel winds are howling, grasping, tearing on the Machinist's gear. Narrow passages lead from the Great City all the way around the Red Wasteland and the Acid Wastes to the Great Beyond. "
						+ "No matter the time of the day, it seems as if the storms hiding in the deep beneath the passes try to drag one down with them. It is said, that the Howling Cliffs once bordered to a massive ocean of sparkling azure water. "
						+ "Now however the Machinist doubts that anyone can even describe what kind of colour azure is supposed to be. \n");
				break;
			case "BoilingLakes":
				println("If one talks about 'the wild' one mostly describes the Boiling Lakes as they are one of the few places to find water. "
						+ "Only problem is, the geysirs and volcanic activities in the area make the process of filling it into some kind of vessel extremely dangerous. "
						+ "The combination of the blazing sun and the unpredictable fontains of boiling water make heat the area even more than normally. "
						+ "Gasping the Machinist loosenes their scarf to whipe away at least some of their sweat.\n");
				break;
			case "TheGreatBeyond":
				println("Miles over miles of deserted space unfold before the Machinist, revealing the mythical lands of the Great Beyond. "
						+ "No one knows what's on the other end of the seemingly endless desert. On the other hand considering what one can find in these lands it isn't really tempting to find out. "
						+ "Stories speak of it as endless fields of grass, rich with life and rich with light. "
						+ "Of trees mildly shaking in the wind, of birds singing in all the tongues of the sky. "
						+ "For a short second the Machinist is reminded of that stories, then they realize that even the last person believing in them is long dead. "
						+ "The Machinist wonders what brought them here now that it feels like the sands burn even through their thick boots. "
						+ "Who in their right minds would not turn around to less deadly areas when the sun rises above the Great Beyond?\n");
				break;
			case "TheChunkyards":
				println("Day and night, there is never a time when the Chunkyards of the Great City lie silent. Perhaps it is the fear for what happens when all is quiet, perhaps the constant struggle for resources. "
						+ "It doesn't matter. Something about the screeching of scrap metal reminds the Machinist of a time long forgotten. Unable to fully grasp it or let it go they remain standing amidst the mountains of trash. "
						+ "Heavy dust rises and falls as the Machinist regards the stoic workers. Maybe in another life they would find themselves at their place. But they did not. "
						+ "The Machinist takes in their work-heavy surroundings as they would never see them again.\n");
				break;
			}
			break;
		case 3: // evening
			println("SUNSET\n");			
			switch (currentLocation) {
			case "TheGreatCity":
				println("The deep shadows of the Great City's numerous chimneys and towers mark the end of an unfinished journey as if the city itself welcomed the Machinist inside her greedy grasp. "
						+ "As the metal doors are closing behind a turmoil of voices and hammering steel, of screaming pipes and blazing furnaces engulf them. "
						+ "What is so notable about the outside anyway? "
						+ "Anonymous faces, wearing masks or goggles, greet the Machinist as if they had never been away. "
						+ "There is no regret about leaving the world to rot outside the safe city walls. "
						+ "After all, there are apparatus to construct, failures to fix. There has never been a point in it in the first place. "
						+ "Indifferent the Machinist sheds their tools on a simple working table, considering the rusted pair of tongs with an ineffable yearning. Then, they put the thougt aside. "
						+ "There is so much work to do. "
						+ "And scant time. \n");
				gamestate = 3;
				break;
			case "RedWastelands":
				println("Even though the sun is setting the heat the Red Wastelands collected over the day is still nearly unbearable. Hopefully the air will cool down a bit soon.\n");
				gamestate = 2;
				break;
			case "AcidWastes":
				println("There is nothing pleasant about the Acid Wastes. And it would not get better at night. When the light is gone traveling across the Acid Wastes means almost certain death. "
						+ "On the other hand the ponds of acid could make a natural defense against most of the nocturnal predators. "
						+ "Only their goggles to protect their eyes the Machinist wonders about their next steps.\n");
				break;
			case "HowlingCliffs":
				println("With the sun setting, the Howling Cliffs are the only part of the country that isn't getting more deadly. For a few hours each day, or so they say, the winds seem to seize, making the passage possible. "
						+ "No matter the time of the day, it seems as if the storms hiding in the deep beneath the passes try to drag one down with them. It is said, that the Howling Cliffs once bordered to a massive ocean of sparkling azure water. "
						+ "Now however the Machinist doubts that anyone can even describe what kind of colour azure is supposed to be. \n");
				break;
			case "BoilingLakes":
				println("If one talks about 'the wild' one mostly describes the Boiling Lakes as they are one of the few places to find water. "
						+ "Only problem is, the geysirs and volcanic activities in the area make the process of filling it into some kind of vessel extremely dangerous. "
						+ "The Machinist cocks their head. Is that wind? Somehow the air in the area suddenly feels much colder. "
						+ "Is it enough to approach one of the lakes?\n");
				break;
			case "TheGreatBeyond":
				println("Miles over miles of deserted space unfold before the Machinist, revealing the mythical lands of the Great Beyond. "
						+ "No one knows what's on the other end of the seemingly endless desert. On the other hand considering what one can find in these lands it isn't really tempting to find out. "
						+ "Stories speak of it as endless fields of grass, rich with life and rich with light. "
						+ "Of trees mildly shaking in the wind, of birds singing in all the tongues of the sky. "
						+ "For a short second the Machinist is reminded of that stories, then they realize that even the last person believing in them is long dead. "
						+ "The heat of the day did its best to meld the billions of tons of sand into something different. "
						+ "In the fading daylight beams of light are reflected and diffused by the layers of glass the Machinist breaks with every step.\n");
				gamestate = 2;
				break;
			case "TheChunkyards":
				println("Day and night, there is never a time when the Chunkyards of the Great City lie silent. Perhaps it is the fear for what happens when all is quiet, perhaps the constant struggle for resources. "
						+ "It doesn't matter. Something about the screeching of scrap metal reminds the Machinist of a time long forgotten. Unable to fully grasp it or let it go they remain standing amidst the mountains of trash. "
						+ "The noises from the Great City slowly fade and the workers leave their domain to rest. Curiously the Machinist walks through the field of tools and former apparatus. "
						+ "Perhaps one could find something useful here after all.\n");
				break;
			}
			break;
		default:
			daytime = 0;
			checkForDaytime();
			break;
		}
	}

	private void checkForAction() {
		answer = readLine("What is your current objective? (travel, wait, inspect area, inventory, use objects) \n");
		switch (answer) {
		case "travel":
			answer = readLine("There are several places to look for what is lost: "
					+ countryMap.get(currentLocation)
					+ " Where shall the Machinist travel? \n");
			currentLocation = answer;
			daytime++;
			break;
		case "wait":
			println("This is as good a place to rest as any. An object can be repaired but it takes a different set of skills to fix a failing body. "
					+ "Better to wait and make some miles later.\n");
			daytime++;
			break;
		case "inspect area":
			inspectArea();
			daytime++;
			break;
		case "inventory":
			println("The Machinist currently has " + inventory + " with them.\n");
			break;
		case "use objects":
			useObjects();
			break;
		default:
			checkForAction();
			break;
		}
	}

	private void inspectArea() {
		if (currentLocation.equals("TheChunkyards")
				&& (daytime == 3 || daytime == 0)) {
			println("Amidst the machinery and chunkpiles the Machinist recognizes something that could be useful. "
					+ "Some of the workers seems to be doing a poor job leaving their tools lying around. As they say: "
					+ "Someone's failure is another one's crowbar.\n");
			inventory.add("crowbar");
		} else if (currentLocation.equals("TheChunkyards")
				&& (daytime == 1 || daytime == 2)) {
			println("Some of the workers seem to have forgotten to put away their food after break. "
					+ "it would be a shame to leave that unused for some beasts to find.\n");
			inventory.add("nutrition bars");
		}
	}

	private void useObjects() { // Leeren und F�llen der Flasche, theoretisch
								// auch mehr Objekte m�glich
		answer = readLine("Maybe some of the items " + inventory
				+ " could be put to use.\n ");
		if (answer.equals("filled bottle")
				&& inventory.contains("filled bottle")) {
			println("It has been some time since they last hydrated. The Machinist lowers their scarf to take in what is left of the precious liquid. "
					+ "Before they can stop themselves the vessel makes a hollow sound as the try drink more. There is nothing left. Perhaps it can be refilled somewhere.\n");
			inventory.remove("filled bottle");
			inventory.add("empty bottle");
		} else if (answer.equals("empty bottle")
				&& inventory.contains("empty bottle")
				&& currentLocation.equals("BoilingLakes") && daytime == 0) {
			println("The water seems to have cooled down a bit. Maybe it can be used now. Carefully the Machinist lowers one ungloved finger to the still hot water. "
					+ "Against their expectation they don't burn themselves, even though the nearly boiling water is not the least pleasant on their skin. They manage to refill the bottle.\n");
			inventory.remove("empty bottle");
			inventory.add("filled bottle");
		} else if (answer.equals("empty bottle")
				&& inventory.contains("empty bottle")
				&& currentLocation.equals("BoilingLakes") && daytime != 0) {
			println("There is no use in waiting for better times when there is an empty bottle and one cannot say how long it will be until they have the next chance to refill. "
					+ "Slowly the Machinist opens their bottle to fill it with some of the lakes water, only to flinch away in pain as the boiling hot water burns their skin. "
					+ "Perhaps now is not the time for that.\n");
		}
	}

	private void introScreen() { // Anzeigen des Einf�hrungstextes
		String thisLine = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader(
					"MachinistIntro.txt"));
			while ((thisLine = br.readLine()) != null) {
				println(thisLine);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void analyseLayout() {// locations wird gelesen
		try {
			BufferedReader br = new BufferedReader(new FileReader(
					"locations.txt"));
			while (true) {
				String line = br.readLine();
				if (line == null)
					break;
				parseLine(line);
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void parseLine(String line) {// line wird analysiert und daraus
											// virtuelle Karte erstellt
		StringTokenizer toki = new StringTokenizer(line, ">");
		while (toki.hasMoreTokens()) {
			String from = toki.nextToken().trim();
			String to = toki.nextToken().trim();
			ArrayList<String> places;
			if (countryMap.containsKey(from)) {
				places = countryMap.get(from);
			} else {
				places = new ArrayList<String>();
			}
			places.add(to);
			countryMap.put(from, places);
		}
	}
}
